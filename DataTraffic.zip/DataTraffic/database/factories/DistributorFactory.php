<?php

use Faker\Generator as Faker;

$factory->define(App\Distributor::class, function (Faker $faker) {
    return [
        //
    ];
});
